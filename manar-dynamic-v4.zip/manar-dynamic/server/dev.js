/* লোকাল সার্ভার: নিজের ফোন/কম্পিউটারে সাইট ও ব্যাকএন্ড একসাথে চালায়।
   চালানো:  node server/dev.js        (Node 22 বা তার ওপরের ভার্সন লাগবে)
   তারপর ব্রাউজারে খুলুন:  http://localhost:8080
   ডাটাবেস থাকে data/manar.db ফাইলে। মুছে দিলে নতুন করে শুরু হয়। */
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DatabaseSync } from 'node:sqlite';
import { handle } from './api.js';

const root = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
const PUB = path.join(root, 'public'), PORT = Number(process.env.PORT) || 8080;
fs.mkdirSync(path.join(root, 'data'), { recursive: true });

/* Cloudflare D1 এর মতো করে SQLite কে ব্যবহার করার ছোট আবরণ */
function makeD1(file) {
  const db = new DatabaseSync(file);
  db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
  const clean = (a) => a.map((v) => (v === undefined ? null : typeof v === 'boolean' ? (v ? 1 : 0) : v));
  const prep = (sql) => {
    let args = []; const st = { get: (...a) => db.prepare(sql).get(...a), all: (...a) => db.prepare(sql).all(...a), run: (...a) => db.prepare(sql).run(...a) };   // লাগলে তখন কম্পাইল (টেবিল তৈরির আগে ইনডেক্স প্রস্তুত করা যায়)
    const o = {
      bind: (...a) => { args = clean(a); return o; },
      first: async () => { const r = st.get(...args); return r ? { ...r } : null; },
      all: async () => ({ results: st.all(...args).map((r) => ({ ...r })) }),
      run: async () => { const r = st.run(...args); return { success: true, meta: { changes: Number(r.changes), last_row_id: Number(r.lastInsertRowid) } }; }
    };
    return o;
  };
  return {
    prepare: prep,
    batch: async (list) => { db.exec('BEGIN'); try { const out = []; for (const s of list) out.push(await s.run()); db.exec('COMMIT'); return out; } catch (e) { db.exec('ROLLBACK'); throw e; } }
  };
}
const env = {
  DB: makeD1(path.join(root, 'data', 'manar.db')),
  OWNER_LOGIN: process.env.OWNER_LOGIN || '',
  DEV_FIRST_OWNER: process.env.OWNER_LOGIN ? '' : '1'         // OWNER_LOGIN না দিলে প্রথম যে সাইন আপ করবে সেই মালিক
};

const TYPES = { '.html': 'text/html; charset=utf-8', '.css': 'text/css; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.json': 'application/json', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.ico': 'image/x-icon', '.webmanifest': 'application/manifest+json', '.mp4': 'video/mp4' };

http.createServer(async (req, res) => {
  try {
    const url = new URL(req.url, 'http://' + (req.headers.host || 'localhost'));
    if (url.pathname.startsWith('/api/')) {
      const chunks = []; for await (const c of req) chunks.push(c);
      const hasBody = !['GET', 'HEAD'].includes(req.method);
      const r = await handle(new Request(url, { method: req.method, headers: req.headers, body: hasBody ? Buffer.concat(chunks) : undefined }), env);
      const h = {}; r.headers.forEach((v, k) => { h[k] = v; });
      res.writeHead(r.status, h); res.end(Buffer.from(await r.arrayBuffer())); return;
    }
    let p = decodeURIComponent(url.pathname);
    if (p.startsWith('/public/')) { res.writeHead(302, { location: p.slice(7) || '/' }); res.end(); return; }   // ভুল করে /public/... খুললেও ঠিক পাতায় নেবে
    if (p === '/admin') { res.writeHead(302, { location: '/admin/' }); res.end(); return; }
    if (p.endsWith('/')) p += 'index.html';
    const file = path.normalize(path.join(PUB, p));
    if (!file.startsWith(PUB) || !fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404, { 'content-type': 'text/plain' }); res.end('Not found'); return; }
    res.writeHead(200, { 'content-type': TYPES[path.extname(file).toLowerCase()] || 'application/octet-stream', 'cache-control': 'no-cache' });
    fs.createReadStream(file).pipe(res);
  } catch (e) { console.error(e); res.writeHead(500); res.end('Server error'); }
}).listen(PORT, () => {
  console.log('\n  Manar BD চালু হয়েছে:  http://localhost:' + PORT);
  console.log('  অ্যাডমিন প্যানেল:    http://localhost:' + PORT + '/admin/');
  console.log(env.OWNER_LOGIN ? '  মালিক: ' + env.OWNER_LOGIN : '  প্রথম যে অ্যাকাউন্ট খুলবেন সেটাই মালিক (অ্যাডমিন) হবে।');
});
