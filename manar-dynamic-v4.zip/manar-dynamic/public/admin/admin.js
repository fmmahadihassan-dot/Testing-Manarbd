/* Manar BD – অ্যাডমিন প্যানেল (সাধারণ JavaScript, কোনো লাইব্রেরি নেই) */
(function () {
  'use strict';
  var S = window.STORE, app = document.getElementById('app'), me = null;
  var money = function (n) { return '৳' + Number(n || 0).toLocaleString('en-IN'); };
  var esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var when = function (ms) { return new Date(ms).toLocaleString('en-GB', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' }); };
  var STATUS = { pending: 'Pending', confirmed: 'Confirmed', shipped: 'On the way', delivered: 'Delivered', cancelled: 'Cancelled' };

  /* ---------- API ---------- */
  function api(path, o) {
    o = o || {}; var h = { 'X-Requested-With': 'fetch' };
    if (o.json) h['Content-Type'] = 'application/json'; if (o.raw && o.raw.type) h['Content-Type'] = o.raw.type;
    return fetch('/api/' + path, { method: o.method || (o.json || o.raw ? 'POST' : 'GET'), headers: h, credentials: 'same-origin', body: o.json ? JSON.stringify(o.json) : o.raw })
      .then(function (r) { return r.json().catch(function () { return {}; }).then(function (j) { if (!r.ok) { var e = new Error(j.error || 'Request failed'); e.status = r.status; throw e; } return j; }); });
  }
  var tt; function toast(m, bad) { var e = $('#toast'); e.textContent = m; e.className = 'toast show' + (bad ? ' bad' : ''); clearTimeout(tt); tt = setTimeout(function () { e.className = 'toast'; }, 2600); }
  var fail = function (e) { toast(e.message || 'Something went wrong', true); };

  /* ---------- ছবি ছোট করা (ব্রাউজারেই) ---------- */
  function resize(file, maxW, q) {
    return new Promise(function (res, rej) {
      var img = new Image(), u = URL.createObjectURL(file);
      img.onload = function () {
        var k = Math.min(1, maxW / img.width), c = document.createElement('canvas'); c.width = Math.round(img.width * k); c.height = Math.round(img.height * k);
        var x = c.getContext('2d'); x.fillStyle = '#fff'; x.fillRect(0, 0, c.width, c.height); x.drawImage(img, 0, 0, c.width, c.height); URL.revokeObjectURL(u);
        c.toBlob(function (b) { b ? res(b) : rej(new Error('Could not read this image')); }, 'image/jpeg', q);
      };
      img.onerror = function () { rej(new Error('Could not read this image')); }; img.src = u;
    });
  }
  function upload(blob) { return api('admin/upload', { raw: blob }).then(function (j) { return j.url; }); }

  /* ---------- কাঠামো ---------- */
  var TABS = [['', 'Dashboard'], ['orders', 'Orders'], ['products', 'Products'], ['banners', 'Banners'], ['settings', 'Offers'], ['users', 'Users']];
  function shell(active, html, pending) {
    app.innerHTML = '<header class="bar"><div class="wrap bar-row"><a class="brand" href="#/">Manar <b>BD</b> Admin</a><div class="bar-actions"><a class="btn line sm" href="/">View shop</a><button class="btn line sm" id="out">Sign out</button></div></div>' +
      '<nav class="tabs">' + TABS.map(function (t) { return '<a href="#/' + t[0] + '" class="' + (t[0] === active ? 'on' : '') + '">' + t[1] + (t[0] === 'orders' && pending ? '<span class="cnt">' + pending + '</span>' : '') + '</a>'; }).join('') + '</nav></header>' +
      '<main class="wrap">' + html + '</main>';
    $('#out').onclick = function () { api('auth/logout', { method: 'POST', json: {} }).then(function () { me = null; route(); }); };
  }
  var pendingCount = 0;
  function loading() { app.innerHTML = '<div class="login"><p class="muted">Loading…</p></div>'; }

  /* ---------- লগইন ---------- */
  function loginView(msg) {
    app.innerHTML = '<div class="login"><h2>Manar <span style="color:var(--accent-strong)">BD</span> Admin</h2>' + (msg ? '<p class="msg bad">' + esc(msg) + '</p>' : '') +
      '<form class="card" id="lf"><label class="f">Email or mobile<input id="l1" autocomplete="username" placeholder="name@email.com or 01XXXXXXXXX"></label>' +
      '<label class="f">Password<input id="l2" type="password" autocomplete="current-password"></label><button class="btn" type="submit">Sign in</button><p class="muted" style="margin:0;font-size:.85rem">Use the same account you use on the shop. Only admins can enter.</p></form><a href="/">← Back to shop</a></div>';
    $('#lf').onsubmit = function (e) {
      e.preventDefault(); var b = $('button', e.target); b.disabled = true;
      api('auth/login', { json: { login: $('#l1').value, password: $('#l2').value } }).then(function (j) { me = j.user; route(); }, function (er) { loginView(er.message); });
    };
  }

  /* ---------- ড্যাশবোর্ড ---------- */
  function dashboard() {
    api('admin/stats').then(function (s) {
      pendingCount = s.pending;
      shell('', '<h2>Dashboard</h2><div class="tiles">' +
        '<div class="tile"><b>' + s.pending + '</b><span>Pending orders</span></div>' +
        '<div class="tile"><b>' + s.today.n + '</b><span>Orders, last 24 h · ' + money(s.today.s) + '</span></div>' +
        '<div class="tile"><b>' + money(s.all.s) + '</b><span>Total sales · ' + s.all.n + ' orders</span></div>' +
        '<div class="tile"><b>' + money(s.delivered.s) + '</b><span>Delivered · ' + s.delivered.n + ' orders</span></div>' +
        '<div class="tile"><b>' + s.products + '</b><span>Products</span></div><div class="tile"><b>' + s.users + '</b><span>Customers & staff</span></div></div>' +
        '<div class="head"><h3>Latest orders</h3><a href="#/orders">See all</a></div>' + orderRows(s.recent), pendingCount);
    }, fail);
  }
  function orderRows(list) {
    return list.length ? '<div class="rows">' + list.map(function (o) {
      return '<a class="row" href="#/orders/' + o.id + '"><div class="grow"><b>' + esc(o.number) + ' · ' + esc(o.name) + '</b><small>' + when(o.created) + ' · ' + o.items.length + ' item(s) · ' + (o.via === 'whatsapp' ? 'WhatsApp' : 'Website') + '</small></div><div style="text-align:right"><b>' + money(o.total) + '</b><br><span class="pill ' + o.status + '">' + STATUS[o.status] + '</span></div></a>';
    }).join('') + '</div>' : '<p class="muted">No orders yet.</p>';
  }

  /* ---------- অর্ডার ---------- */
  var ordFilter = { status: '', q: '' };
  function orders() {
    var qs = 'admin/orders?status=' + encodeURIComponent(ordFilter.status) + '&q=' + encodeURIComponent(ordFilter.q);
    api(qs).then(function (j) {
      shell('orders', '<div class="head"><h2>Orders</h2></div><div class="card"><div class="grid2"><label class="f">Status<select id="fs"><option value="">All</option>' +
        Object.keys(STATUS).map(function (k) { return '<option value="' + k + '"' + (ordFilter.status === k ? ' selected' : '') + '>' + STATUS[k] + '</option>'; }).join('') + '</select></label>' +
        '<label class="f">Search<input id="fq" placeholder="Order no, name or mobile" value="' + esc(ordFilter.q) + '"></label></div></div>' + orderRows(j.orders) + (j.more ? '<p class="muted">Showing the latest 30. Use search to find older orders.</p>' : ''), pendingCount);
      $('#fs').onchange = function () { ordFilter.status = this.value; orders(); };
      var t; $('#fq').oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { ordFilter.q = v; orders(); }, 450); };
      var f = $('#fq'); if (ordFilter.q) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); }
    }, fail);
  }
  function orderDetail(id) {
    var find = function () { return api('admin/orders/' + id).then(function (j) { return j.order; }); };
    find().then(function (o) {
      if (!o) { shell('orders', '<p class="msg bad">Order not found.</p><a href="#/orders">← Back</a>', pendingCount); return; }
      var wa = '88' + o.phone;
      shell('orders', '<a href="#/orders">← All orders</a><div class="card"><div class="head"><h2>' + esc(o.number) + '</h2><span class="pill ' + o.status + '">' + STATUS[o.status] + '</span></div><small class="muted">' + when(o.created) + ' · ' + (o.via === 'whatsapp' ? 'WhatsApp order' : 'Website order') + '</small>' +
        '<ul class="items">' + o.items.map(function (i) { return '<li><span>' + esc(i.name) + (i.variant ? ' (' + esc(i.variant) + ')' : '') + ' × ' + i.qty + '</span><b>' + money(i.price * i.qty) + '</b></li>'; }).join('') + '</ul>' +
        '<div class="sum"><div><span>Subtotal</span><span>' + money(o.subtotal) + '</span></div>' + (o.discount ? '<div><span>Promo ' + esc(o.promo) + '</span><span>−' + money(o.discount) + '</span></div>' : '') + '<div><span>Delivery</span><span>' + (o.delivery ? money(o.delivery) : 'Free') + '</span></div><div class="t"><span>Total (Cash on Delivery)</span><span>' + money(o.total) + '</span></div></div></div>' +
        '<div class="card"><h3>Customer</h3><div><b>' + esc(o.name) + '</b><br>' + esc(o.phone) + '<br>' + esc(o.dist) + '<br>' + esc(o.address) + (o.note ? '<br><i class="muted">Note: ' + esc(o.note) + '</i>' : '') + '</div>' +
        '<div class="stat-btns"><a class="btn line sm" href="tel:' + esc(o.phone) + '">Call</a><a class="btn line sm" target="_blank" rel="noopener" href="https://wa.me/' + esc(wa) + '">WhatsApp</a>' + (o.userId ? '<span class="pill">Has account</span>' : '<span class="pill off">Guest</span>') + '</div></div>' +
        '<div class="card"><h3>Update status</h3><div class="stat-btns">' + Object.keys(STATUS).map(function (k) { return '<button class="btn sm ' + (o.status === k ? '' : 'line') + '" data-st="' + k + '">' + STATUS[k] + '</button>'; }).join('') + '</div>' +
        '<label class="f">Private note<small>Only admins can see this</small><textarea id="an">' + esc(o.adminNote) + '</textarea></label><button class="btn line" id="san">Save note</button></div>', pendingCount);
      var patch = function (body) { api('admin/orders/' + o.id, { method: 'PATCH', json: body }).then(function () { toast('Saved'); orderDetail(id); }, fail); };
      $$('[data-st]').forEach(function (b) { b.onclick = function () { patch({ status: b.dataset.st }); }; });
      $('#san').onclick = function () { patch({ adminNote: $('#an').value }); };
    }, fail);
  }

  /* ---------- প্রোডাক্ট তালিকা ---------- */
  var prodQ = '';
  function products() {
    api('admin/products').then(function (j) {
      var draw = function () {
        var list = j.products.filter(function (p) { return !prodQ || p.name.toLowerCase().indexOf(prodQ.toLowerCase()) > -1; });
        $('#plist').innerHTML = list.length ? list.map(function (p) {
          var price = p.variants ? Math.min.apply(null, p.variants.map(function (v) { return v.price; })) : p.price;
          return '<div class="row">' + (p.imgSm || p.img ? '<img class="thumb" src="' + esc(fileUrl(p.imgSm || p.img)) + '" alt="">' : '<div class="thumb">' + esc(p.name.charAt(0)) + '</div>') +
            '<a class="grow" href="#/product/' + esc(p.id) + '" style="color:inherit;text-decoration:none"><b>' + esc(p.name) + '</b><small>' + (p.variants ? 'from ' : '') + money(price) + (p.active ? '' : ' · <span class="pill off">Hidden</span>') + '</small></a>' +
            '<div style="text-align:center"><label class="sw" title="In stock"><input type="checkbox" data-stock="' + esc(p.id) + '"' + (p.inStock !== false ? ' checked' : '') + '><i></i></label><small class="muted">Stock</small></div></div>';
        }).join('') : '<p class="muted">No products found.</p>';
        $$('[data-stock]').forEach(function (c) { c.onchange = function () { api('admin/products/' + c.dataset.stock, { method: 'PATCH', json: { inStock: c.checked } }).then(function () { toast(c.checked ? 'In stock' : 'Marked out of stock'); }, function (e) { fail(e); c.checked = !c.checked; }); }; });
      };
      shell('products', '<div class="head"><h2>Products (' + j.products.length + ')</h2><a class="btn" href="#/product/new">+ Add product</a></div><input id="pq" placeholder="Search products" value="' + esc(prodQ) + '"><div class="rows" id="plist"></div>', pendingCount);
      draw(); $('#pq').oninput = function () { prodQ = this.value; draw(); };
    }, fail);
  }

  /* ---------- প্রোডাক্ট ফর্ম ---------- */
  var SPEC_FIELDS = [['model', 'Model'], ['type', 'Type / category name'], ['warranty', 'Warranty (e.g. 12 months)'], ['capacity', 'Capacity (e.g. 1.8 L)'], ['watt', 'Power (e.g. 1500 W)'], ['voltage', 'Operating voltage'],
    ['material', 'Body material'], ['battery', 'Battery capacity (e.g. 1000 mAh)'], ['light', 'Light / torch'], ['chargingTime', 'Charging time'], ['usageTime', 'Usage time']];
  var fileUrl = function (u) { return /^(images|\/api)/.test(u) ? '/' + u.replace(/^\//, '') : u; };
  function productForm(id) {
    var isNew = id === 'new';
    (isNew ? Promise.resolve({ products: [] }) : api('admin/products')).then(function (j) {
      var p = isNew ? { inStock: true, free: true, tags: [], gallery: [] } : j.products.filter(function (x) { return x.id === id; })[0];
      if (!p) { shell('products', '<p class="msg bad">Product not found.</p>', pendingCount); return; }
      var imgs = (p.gallery && p.gallery.length ? p.gallery : (p.img ? [p.img] : [])).map(function (u, i) { return { full: u, sm: i === 0 && p.imgSm ? p.imgSm : u }; });
      var vars = (p.variants || []).map(function (v) { return { name: v.name, price: v.price, old: v.old || '' }; });
      var tagList = Object.keys(S.tagNames);
      var tg = function (k, label, on) { return '<label class="chk"><input type="checkbox" data-k="' + k + '"' + (on ? ' checked' : '') + '> ' + label + '</label>'; };
      var tri = function (k, label) { var v = p[k] === true ? 'y' : p[k] === false ? 'n' : ''; return '<label class="f">' + label + '<select data-k="' + k + '"><option value="">Not shown</option><option value="y"' + (v === 'y' ? ' selected' : '') + '>Yes</option><option value="n"' + (v === 'n' ? ' selected' : '') + '>No</option></select></label>'; };
      shell('products', '<a href="#/products">← Products</a><h2>' + (isNew ? 'Add product' : 'Edit product') + '</h2><form id="pf" novalidate>' +
        '<div class="card"><h3>Basic</h3><label class="f">Product name<input data-k="name" value="' + esc(p.name) + '" maxlength="120"></label>' +
        '<label class="f">Short line<small>Shown under the name on the card</small><input data-k="short" value="' + esc(p.short) + '" maxlength="90"></label>' +
        '<div class="grid2"><label class="f">Brand<input data-k="brand" value="' + esc(p.brand) + '"></label><label class="f">Badge<small>e.g. Bestseller, New</small><input data-k="badge" value="' + esc(p.badge) + '" maxlength="30"></label></div>' +
        '<div><b style="font-size:.88rem">Categories</b><div class="chks" id="tags" style="margin-top:6px">' + tagList.map(function (t) { return '<label class="chk"><input type="checkbox" value="' + t + '"' + ((p.tags || []).indexOf(t) > -1 ? ' checked' : '') + '> ' + esc(S.tagNames[t]) + '</label>'; }).join('') + '</div></div></div>' +
        '<div class="card"><h3>Images</h3><p class="muted" style="margin:0">The first image is the main one. Square photos (about 1000 × 1000) look best.</p><div class="imgs" id="imgs"></div><input type="file" id="fi" accept="image/*" multiple hidden>' +
        '<label class="f">Video link <small>Optional. YouTube link or a direct .mp4 link</small><input data-k="video" value="' + esc(p.video) + '" placeholder="https://youtu.be/..."></label></div>' +
        '<div class="card"><h3>Price</h3><div id="pricebox"></div>' +
        '<label class="chk"><input type="checkbox" data-k="free"' + (p.free !== false ? ' checked' : '') + '> Free delivery for this product</label><label class="f" id="chg">Delivery charge (৳)<input data-k="charge" type="number" min="0" inputmode="numeric" value="' + esc(p.charge || '') + '"></label></div>' +
        '<div class="card"><h3>Stock & visibility</h3><label class="chk"><input type="checkbox" data-k="inStock"' + (p.inStock !== false ? ' checked' : '') + '> In stock</label><label class="chk"><input type="checkbox" data-k="active"' + (p.active !== false ? ' checked' : '') + '> Show in shop</label>' +
        '<label class="chk"><input type="checkbox" data-k="hot"' + (p.hot ? ' checked' : '') + '> Hot deal</label><label class="chk"><input type="checkbox" data-k="popular"' + (p.popular ? ' checked' : '') + '> Popular</label></div>' +
        '<div class="card"><h3>Description</h3><label class="f">About<textarea data-k="about" maxlength="1500">' + esc(p.about) + '</textarea></label>' +
        '<label class="f">Highlights<small>One per line</small><textarea data-k="features">' + esc((p.features || []).join('\n')) + '</textarea></label></div>' +
        '<div class="card"><h3>Product details</h3><p class="muted" style="margin:0">Fill only what applies. Empty fields are hidden on the shop.</p><div class="grid2">' +
        SPEC_FIELDS.map(function (f) { return '<label class="f">' + f[1] + '<input data-k="' + f[0] + '" value="' + esc(p[f[0]]) + '" maxlength="60"></label>'; }).join('') + tri('autoOff', 'Auto switch-off') + tri('eco', 'Eco friendly') + '</div>' +
        '<label class="f">Extra details<small>One per line, like: Colour: Black</small><textarea data-k="specs">' + esc((p.specs || []).map(function (r) { return r[0] + ': ' + r[1]; }).join('\n')) + '</textarea></label></div>' +
        '<p class="msg bad" id="perr" hidden></p><div class="sticky-save"><button class="btn" type="submit">' + (isNew ? 'Add product' : 'Save changes') + '</button>' + (isNew ? '' : '<button class="btn danger" type="button" id="pdel">Delete</button>') + '</div></form>', pendingCount);

      var F = $('#pf'), val = function (k) { var e = $('[data-k="' + k + '"]', F); return e ? (e.type === 'checkbox' ? e.checked : e.value.trim()) : ''; };
      function drawImgs() {
        $('#imgs').innerHTML = imgs.map(function (m, i) { return '<div class="im"><img src="' + esc(fileUrl(m.sm || m.full)) + '" alt="">' + (i === 0 ? '<span class="tag">Main</span>' : '') +
          '<div class="acts">' + (i > 0 ? '<button type="button" data-main="' + i + '" title="Make main">★</button>' : '') + '<button type="button" data-rm="' + i + '" title="Remove">✕</button></div></div>'; }).join('') +
          '<label class="add-im" for="fi">+ Add<br>photo</label>';
        $$('[data-main]').forEach(function (b) { b.onclick = function () { var m = imgs.splice(+b.dataset.main, 1)[0]; imgs.unshift(m); drawImgs(); }; });
        $$('[data-rm]').forEach(function (b) { b.onclick = function () { imgs.splice(+b.dataset.rm, 1); drawImgs(); }; });
      }
      drawImgs();
      $('#fi').onchange = function () {
        var files = Array.prototype.slice.call(this.files).slice(0, 10 - imgs.length); this.value = ''; if (!files.length) return;
        toast('Uploading ' + files.length + ' photo(s)…');
        files.reduce(function (chain, f) {
          return chain.then(function () { return Promise.all([resize(f, 1100, .82), resize(f, 560, .8)]).then(function (b) { return Promise.all([upload(b[0]), upload(b[1])]); }).then(function (u) { imgs.push({ full: u[0], sm: u[1] }); drawImgs(); }); });
        }, Promise.resolve()).then(function () { toast('Photos added'); }, fail);
      };
      function drawPrice() {
        var hasV = vars.length > 0;
        $('#pricebox').innerHTML = hasV
          ? '<p class="muted" style="margin:0">This product has options (like sizes). Each option has its own price.</p>' + vars.map(function (v, i) {
            return '<div class="vr"><input data-vn="' + i + '" placeholder="Option name" value="' + esc(v.name) + '"><input data-vp="' + i + '" type="number" inputmode="numeric" placeholder="Price" value="' + esc(v.price) + '"><input data-vo="' + i + '" type="number" inputmode="numeric" placeholder="Old price" value="' + esc(v.old) + '"><button type="button" class="btn danger sm" data-vr="' + i + '">✕</button></div>'; }).join('') + '<button type="button" class="btn line sm" id="vadd">+ Add option</button> <button type="button" class="btn line sm" id="vnone">Use a single price instead</button>'
          : '<div class="grid2 keep"><label class="f">Price (৳)<input data-k="price" type="number" inputmode="numeric" min="1" value="' + esc(p.price || '') + '"></label><label class="f">Old price (৳)<small>Optional. Shows the discount %</small><input data-k="old" type="number" inputmode="numeric" min="0" value="' + esc(p.old || '') + '"></label></div><div id="dpv" class="muted"></div><button type="button" class="btn line sm" id="vadd">Has options (sizes, colours…)?</button>';
        $$('[data-vn]').forEach(function (e) { e.oninput = function () { vars[+e.dataset.vn].name = e.value; }; });
        $$('[data-vp]').forEach(function (e) { e.oninput = function () { vars[+e.dataset.vp].price = e.value; }; });
        $$('[data-vo]').forEach(function (e) { e.oninput = function () { vars[+e.dataset.vo].old = e.value; }; });
        $$('[data-vr]').forEach(function (e) { e.onclick = function () { vars.splice(+e.dataset.vr, 1); drawPrice(); }; });
        var add = $('#vadd'); if (add) add.onclick = function () { if (!hasV) { var pr = val('price'), od = val('old'); vars.push({ name: '', price: pr, old: od }); } vars.push({ name: '', price: '', old: '' }); drawPrice(); };
        var none = $('#vnone'); if (none) none.onclick = function () { var v = vars[0] || {}; p.price = v.price; p.old = v.old; vars = []; drawPrice(); };
        var pe = $('[data-k="price"]'), oe = $('[data-k="old"]');
        if (pe) { var show = function () { var a = +pe.value, b = +oe.value; $('#dpv').textContent = b > a && a > 0 ? 'Discount shown: ' + Math.round((1 - a / b) * 100) + '% OFF (You save ' + money(b - a) + ')' : ''; }; pe.oninput = oe.oninput = show; show(); }
      }
      drawPrice();
      var chg = function () { $('#chg').hidden = $('[data-k="free"]').checked; }; $('[data-k="free"]').onchange = chg; chg();

      F.onsubmit = function (e) {
        e.preventDefault(); var err = $('#perr'); err.hidden = true;
        var body = { name: val('name'), short: val('short'), brand: val('brand'), badge: val('badge'), video: val('video'), about: val('about'), free: val('free'), charge: val('charge'), inStock: val('inStock'), active: val('active'), hot: val('hot'), popular: val('popular'),
          tags: $$('#tags input:checked').map(function (c) { return c.value; }), gallery: imgs.map(function (m) { return m.full; }), img: imgs[0] && imgs[0].full, imgSm: imgs[0] && imgs[0].sm,
          features: val('features').split('\n'), specs: val('specs').split('\n').map(function (l) { var i = l.indexOf(':'); return i > 0 ? [l.slice(0, i), l.slice(i + 1)] : null; }).filter(Boolean) };
        SPEC_FIELDS.forEach(function (f) { body[f[0]] = val(f[0]); });
        ['autoOff', 'eco'].forEach(function (k) { var v = val(k); if (v === 'y') body[k] = true; else if (v === 'n') body[k] = false; });
        if (vars.length) body.variants = vars.map(function (v) { return { name: v.name, price: v.price, old: v.old }; }); else { body.price = val('price'); body.old = val('old'); }
        var b = $('button[type=submit]', F); b.disabled = true;
        api('admin/products' + (isNew ? '' : '/' + encodeURIComponent(id)), { method: isNew ? 'POST' : 'PUT', json: body }).then(function () { toast('Saved'); location.hash = '#/products'; },
          function (er) { err.textContent = er.message; err.hidden = false; err.scrollIntoView({ block: 'center', behavior: 'smooth' }); b.disabled = false; });
      };
      var del = $('#pdel'); if (del) del.onclick = function () { if (confirm('Delete "' + p.name + '" permanently? To only hide it, untick "Show in shop" instead.')) api('admin/products/' + encodeURIComponent(id), { method: 'DELETE' }).then(function () { toast('Deleted'); location.hash = '#/products'; }, fail); };
    }, fail);
  }

  /* ---------- ব্যানার ---------- */
  function banners() {
    Promise.all([api('admin/settings'), api('admin/products')]).then(function (r) {
      var hero = r[0].hero.slice(), prods = r[1].products;
      var draw = function () {
        $('#blist').innerHTML = hero.map(function (h, i) {
          return '<div class="card"><img class="banner-im" src="' + esc(fileUrl(h.img)) + '" alt=""><label class="f">Opens this product when tapped<select data-bp="' + i + '"><option value="">— none —</option>' +
            prods.map(function (p) { return '<option value="' + esc(p.id) + '"' + (h.product === p.id ? ' selected' : '') + '>' + esc(p.name) + '</option>'; }).join('') + '</select></label>' +
            '<label class="f">Short description <small>For screen readers</small><input data-ba="' + i + '" value="' + esc(h.alt) + '"></label><div class="stat-btns"><button type="button" class="btn line sm" data-bu="' + i + '"' + (i === 0 ? ' disabled' : '') + '>↑ Up</button><button type="button" class="btn line sm" data-bd="' + i + '"' + (i === hero.length - 1 ? ' disabled' : '') + '>↓ Down</button><button type="button" class="btn danger sm" data-br="' + i + '">Remove</button></div></div>';
        }).join('') || '<p class="muted">No banners yet. The banner section is hidden on the shop.</p>';
        $$('[data-bp]').forEach(function (e) { e.onchange = function () { hero[+e.dataset.bp].product = e.value; }; });
        $$('[data-ba]').forEach(function (e) { e.oninput = function () { hero[+e.dataset.ba].alt = e.value; }; });
        $$('[data-bu]').forEach(function (e) { e.onclick = function () { var i = +e.dataset.bu, t = hero[i]; hero[i] = hero[i - 1]; hero[i - 1] = t; draw(); }; });
        $$('[data-bd]').forEach(function (e) { e.onclick = function () { var i = +e.dataset.bd, t = hero[i]; hero[i] = hero[i + 1]; hero[i + 1] = t; draw(); }; });
        $$('[data-br]').forEach(function (e) { e.onclick = function () { hero.splice(+e.dataset.br, 1); draw(); }; });
      };
      shell('banners', '<h2>Banners</h2><div class="card"><p class="muted" style="margin:0">Use one image per banner, 16:9 (for example 1920 × 1080 px). The same image shows on mobile and desktop.</p><input type="file" id="bf" accept="image/*" hidden><label class="btn line" for="bf">+ Add banner image</label></div><div id="blist" class="rows"></div><div class="sticky-save"><button class="btn" id="bsave">Save banners</button></div>', pendingCount);
      draw();
      $('#bf').onchange = function () { var f = this.files[0]; this.value = ''; if (!f) return; toast('Uploading…'); resize(f, 1920, .85).then(upload).then(function (u) { hero.push({ img: u, product: '', alt: '' }); draw(); toast('Image added. Remember to save.'); }, fail); };
      $('#bsave').onclick = function () { api('admin/settings', { method: 'PUT', json: { hero: hero } }).then(function () { toast('Banners saved'); }, fail); };
    }, fail);
  }

  /* ---------- অফার ও প্রোমো ---------- */
  function settings() {
    api('admin/settings').then(function (s) {
      var o = s.offer, pr = s.promo;
      shell('settings', '<h2>Offers</h2><form id="sf"><div class="card"><h3>Free delivery offer</h3><label class="chk"><input type="checkbox" id="oe"' + (o.enabled ? ' checked' : '') + '> Offer is ON</label>' +
        '<div class="grid2 keep"><label class="f">Minimum order (৳)<input id="om" type="number" inputmode="numeric" value="' + esc(o.minOrder) + '"></label></div>' +
        '<label class="f">Scrolling text at the top<input id="ot" maxlength="160" value="' + esc(o.text) + '"></label>' +
        '<div class="grid2 keep"><label class="f">Start date <small>Optional</small><input id="os" type="date" value="' + esc(o.startDate) + '"></label><label class="f">End date <small>Optional</small><input id="oz" type="date" value="' + esc(o.endDate) + '"></label></div></div>' +
        '<div class="card"><h3>Promo code</h3><div class="grid2 keep"><label class="f">Code<input id="pc" maxlength="20" value="' + esc(pr.code) + '" style="text-transform:uppercase"></label><label class="f">Discount %<input id="pp" type="number" inputmode="numeric" min="1" max="90" value="' + esc(pr.percent) + '"></label></div></div>' +
        '<div class="sticky-save"><button class="btn" type="submit">Save</button></div></form>', pendingCount);
      $('#sf').onsubmit = function (e) {
        e.preventDefault();
        api('admin/settings', { method: 'PUT', json: { offer: { enabled: $('#oe').checked, minOrder: $('#om').value, text: $('#ot').value, startDate: $('#os').value, endDate: $('#oz').value }, promo: { code: $('#pc').value, percent: $('#pp').value } } }).then(function () { toast('Saved'); }, fail);
      };
    }, fail);
  }

  /* ---------- ইউজার ---------- */
  var userQ = '';
  function users() {
    api('admin/users?q=' + encodeURIComponent(userQ)).then(function (j) {
      var owner = me.role === 'owner';
      shell('users', '<h2>Users</h2>' + (owner ? '' : '<p class="muted">Only the owner can make admins or reset passwords.</p>') + '<input id="uq" placeholder="Search name, email or mobile" value="' + esc(userQ) + '"><div class="rows">' +
        j.users.map(function (u) {
          return '<div class="row"><div class="thumb">' + esc((u.name || '?').charAt(0).toUpperCase()) + '</div><div class="grow"><b>' + esc(u.name) + '</b><small>' + esc(u.email || u.phone) + ' · ' + u.orders + ' order(s)</small></div>' +
            '<span class="pill ' + (u.role === 'customer' ? 'off' : '') + '">' + u.role + '</span>' +
            (owner && u.role !== 'owner' ? '<div class="stat-btns"><button class="btn line sm" data-role="' + u.id + '" data-to="' + (u.role === 'admin' ? 'customer' : 'admin') + '">' + (u.role === 'admin' ? 'Remove admin' : 'Make admin') + '</button><button class="btn line sm" data-rs="' + u.id + '">Reset password</button></div>' : '') + '</div>';
        }).join('') + '</div>', pendingCount);
      var t; $('#uq').oninput = function () { var v = this.value; clearTimeout(t); t = setTimeout(function () { userQ = v; users(); }, 450); };
      var f = $('#uq'); if (userQ) { f.focus(); f.setSelectionRange(f.value.length, f.value.length); }
      $$('[data-role]').forEach(function (b) { b.onclick = function () { api('admin/users/' + b.dataset.role, { method: 'PATCH', json: { role: b.dataset.to } }).then(function () { toast('Updated'); users(); }, fail); }; });
      $$('[data-rs]').forEach(function (b) { b.onclick = function () { var pw = prompt('Type a new temporary password (at least 6 characters). Tell the customer to change it after signing in.'); if (pw) api('admin/users/' + b.dataset.rs + '/reset', { json: { password: pw } }).then(function () { toast('Password changed'); }, fail); }; });
    }, fail);
  }

  /* ---------- রাউটার ---------- */
  function route() {
    if (!me) { loginView(); return; }
    if (me.role === 'customer') { app.innerHTML = '<div class="login"><h2>No admin access</h2><p class="msg bad">This account (' + esc(me.name) + ') is not an admin.</p><a class="btn" href="/">Back to shop</a><button class="btn line" id="o2">Sign out</button></div>'; $('#o2').onclick = function () { api('auth/logout', { method: 'POST', json: {} }).then(function () { me = null; route(); }); }; return; }
    var h = location.hash.replace(/^#\/?/, '').split('/'), a = h[0] || '';
    window.scrollTo(0, 0);
    if (a === '') dashboard(); else if (a === 'orders') h[1] ? orderDetail(h[1]) : orders(); else if (a === 'products') products();
    else if (a === 'product') productForm(decodeURIComponent(h[1] || 'new')); else if (a === 'banners') banners(); else if (a === 'settings') settings(); else if (a === 'users') users(); else dashboard();
  }
  var started = false;
  window.addEventListener('hashchange', function () { if (started) route(); });
  loading(); api('me').then(function (j) { me = j.user; started = true; route(); }, function () { started = true; loginView(); });
})();
